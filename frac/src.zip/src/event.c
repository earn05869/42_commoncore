/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   event.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: supanuso <supanuso@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/01 10:01:16 by supanuso          #+#    #+#             */
/*   Updated: 2025/05/02 13:40:07 by supanuso         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fractol.h"

int	close_window(t_fractol *f)
{
	if (f->img)
		mlx_destroy_image(f->mlx, f->img);
	if (f->win)
		mlx_destroy_window(f->mlx, f->win);
	if (f->mlx)
	{
		mlx_destroy_display(f->mlx);
		free(f->mlx);
	}
	if (f->palette)
		free(f->palette);
	if (f->tmp_buf)
		free(f->tmp_buf);
	exit(EXIT_SUCCESS);
}

int	key_hook(int keycode, t_fractol *f)
{
	// int factor;
	if (keycode == ESC)
		close_window(f);
	if (keycode == SPACE)
	{
		// reset_zoom_bounds(f, pos_x, pos_y, factor);
		// f->zoom_level = 0;
		// printf("zoom level: %d\n", f->zoom_level);
		// render(f);
		color_shift(f);
		render(f);
	}
	if (keycode == PLUS)
		zoom(f, WIDTH / 2, HEIGHT / 2, 1);
	if (keycode == MINUS)
		zoom(f, WIDTH / 2, HEIGHT / 2, -1);
	return (0);
}
